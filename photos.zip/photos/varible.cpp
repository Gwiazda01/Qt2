#include "variable.h"

Varible::Varible(QObject *parent) : QObject(parent)
{

}

Varible::~Varible()
{

}

